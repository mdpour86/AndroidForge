plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "ir.school.lateness"
    compileSdk = 35
    defaultConfig {
        applicationId = "ir.school.lateness"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
