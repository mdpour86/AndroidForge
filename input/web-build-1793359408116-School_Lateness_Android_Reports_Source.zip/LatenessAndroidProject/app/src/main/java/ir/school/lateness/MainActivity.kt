package ir.school.lateness

import android.app.*
import android.os.Bundle
import android.content.*
import android.net.Uri
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.view.*
import android.widget.*
import android.text.*
import org.json.*
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import java.io.*
import android.icu.util.PersianCalendar
import android.graphics.pdf.PdfDocument
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.Canvas

data class Pupil(val id:String,val name:String,val grade:String,val klass:String,val active:Boolean=true)
data class Delay(val id:String,val pupilId:String,val date:String,val createdAt:Long)
class DB(ctx:android.content.Context):SQLiteOpenHelper(ctx,"lateness.db",null,2){
 override fun onCreate(d:SQLiteDatabase){
  d.execSQL("CREATE TABLE pupils(id TEXT PRIMARY KEY,name TEXT NOT NULL,grade TEXT,klass TEXT,active INTEGER DEFAULT 1,created INTEGER)")
  d.execSQL("CREATE TABLE delays(id TEXT PRIMARY KEY,pupil_id TEXT,date TEXT,created INTEGER)")
  d.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY,v TEXT)")
  d.execSQL("INSERT INTO settings(k,v) VALUES('threshold','3')")
 }
 override fun onUpgrade(d:SQLiteDatabase,o:Int,n:Int){
  if(o<2){d.execSQL("ALTER TABLE pupils RENAME TO pupils_old");d.execSQL("CREATE TABLE pupils(id TEXT PRIMARY KEY,name TEXT NOT NULL,grade TEXT,klass TEXT,active INTEGER DEFAULT 1,created INTEGER)");d.execSQL("INSERT INTO pupils(id,name,grade,klass,active,created) SELECT CAST(id AS TEXT),name,grade,klass,active,0 FROM pupils_old");d.execSQL("DROP TABLE pupils_old");d.execSQL("CREATE TABLE delays(id TEXT PRIMARY KEY,pupil_id TEXT,date TEXT,created INTEGER)");d.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY,v TEXT)");d.execSQL("INSERT INTO settings(k,v) VALUES('threshold','3')")}
 }
 fun pupils():List<Pupil>{val a=mutableListOf<Pupil>();readableDatabase.rawQuery("SELECT id,name,grade,klass,active FROM pupils ORDER BY klass,name",null).use{c->while(c.moveToNext())a.add(Pupil(c.getString(0),c.getString(1),c.getString(2)?:"",c.getString(3)?:"",c.getInt(4)==1))};return a}
 fun delays():List<Delay>{val a=mutableListOf<Delay>();readableDatabase.rawQuery("SELECT id,pupil_id,date,created FROM delays",null).use{c->while(c.moveToNext())a.add(Delay(c.getString(0),c.getString(1),c.getString(2),c.getLong(3)))};return a}
 fun addPupil(name:String,grade:String,klass:String,id:String=UUID.randomUUID().toString()){writableDatabase.execSQL("INSERT OR IGNORE INTO pupils(id,name,grade,klass,active,created) VALUES(?,?,?,?,1,?)",arrayOf(id,name,grade,klass,System.currentTimeMillis()))}
 fun markLate(id:String,date:String){val exists=readableDatabase.rawQuery("SELECT 1 FROM delays WHERE pupil_id=? AND date=?",arrayOf(id,date)).use{it.moveToFirst()};if(!exists)writableDatabase.execSQL("INSERT INTO delays(id,pupil_id,date,created) VALUES(?,?,?,?)",arrayOf(UUID.randomUUID().toString(),id,date,System.currentTimeMillis()))}
 fun threshold():Int=readableDatabase.rawQuery("SELECT v FROM settings WHERE k='threshold'",null).use{if(it.moveToFirst())it.getString(0).toIntOrNull()?:3 else 3}
 fun setThreshold(n:Int){writableDatabase.execSQL("INSERT OR REPLACE INTO settings(k,v) VALUES('threshold',?)",arrayOf(n.toString()))}
 fun exportJson():JSONObject{val o=JSONObject();val ps=JSONArray();pupils().forEach{p->ps.put(JSONObject().put("id",p.id).put("name",p.name).put("grade",p.grade).put("className",p.klass).put("active",p.active).put("createdAt",System.currentTimeMillis()))};val rs=JSONArray();delays().forEach{r->rs.put(JSONObject().put("id",r.id).put("studentId",r.pupilId).put("date",r.date).put("createdAt",r.createdAt))};return o.put("students",ps).put("records",rs).put("threshold",threshold()).put("updatedAt",System.currentTimeMillis())}
 fun mergeJson(o:JSONObject){val ps=o.optJSONArray("students")?:JSONArray();for(i in 0 until ps.length()){val p=ps.optJSONObject(i)?:continue;val id=p.optString("id");val name=p.optString("name");if(id.isNotBlank()&&name.isNotBlank())addPupil(name,p.optString("grade"),p.optString("className",p.optString("klass")),id)};val rs=o.optJSONArray("records")?:JSONArray();for(i in 0 until rs.length()){val r=rs.optJSONObject(i)?:continue;val id=r.optString("id");val sid=r.optString("studentId");val date=r.optString("date");if(id.isNotBlank()&&sid.isNotBlank()&&date.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))){writableDatabase.execSQL("INSERT OR IGNORE INTO delays(id,pupil_id,date,created) VALUES(?,?,?,?)",arrayOf(id,sid,date,r.optLong("createdAt",System.currentTimeMillis())))}};if(o.has("threshold"))setThreshold(o.optInt("threshold",3))}
}
class MainActivity:Activity(){
 private lateinit var db:DB;private lateinit var status:TextView;private lateinit var content:LinearLayout
 private val pickCsv=11;private val saveCsv=12;private val saveJson=13;private val pickJson=14;private val saveReportCsv=15;private val saveReportPdf=16
 private var reportCsvText=""; private var reportPdfLines=listOf<String>(); private var reportTitle="گزارش تأخیر ماهانه"
 private fun today():String=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())
 private fun persianDate(iso:String):String { return try { val d=SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(iso)!!; val c=PersianCalendar().apply{time=d}; "${c.get(Calendar.YEAR)}/${(c.get(Calendar.MONTH)+1).toString().padStart(2,'0')}/${c.get(Calendar.DAY_OF_MONTH).toString().padStart(2,'0')}" } catch(_:Exception){iso} }
 private fun csvCell(v:String)="\""+v.replace("\"","\"\"")+"\""
 private fun btn(t:String,f:()->Unit)=Button(this).apply{text=t;setOnClickListener{f()}}
 override fun onCreate(b:Bundle?){super.onCreate(b);db=DB(this);home()}
 private fun base(title:String){val root=LinearLayout(this).apply{orientation=1;setPadding(20,20,20,20);layoutDirection=View.LAYOUT_DIRECTION_RTL};root.addView(TextView(this).apply{text=title;textSize=22f});status=TextView(this).apply{text="ذخیره محلی فعال است؛ بدون اینترنت و وای‌فای کار می‌کند.";textSize=14f};root.addView(status);content=LinearLayout(this).apply{orientation=1};root.addView(content);setContentView(ScrollView(this).apply{addView(root)})}
 private fun home(){base("سامانه ثبت تأخیر دانش‌آموزان");content.addView(btn("ثبت تأخیر امروز"){lateScreen()});content.addView(btn("مدیریت و ورود گروهی دانش‌آموزان"){studentScreen()});content.addView(btn("گزارش ماهانه شمسی"){reportScreen()});content.addView(btn("همگام‌سازی با کامپیوتر مدرسه"){syncDialog()});content.addView(btn("خروجی پشتیبان JSON"){startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).setType("application/json").putExtra(Intent.EXTRA_TITLE,"backup-lateness.json"),saveJson)});content.addView(btn("بازیابی پشتیبان JSON"){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE),pickJson)})}
 private fun lateScreen(){base("ثبت تأخیر امروز");val search=EditText(this).apply{hint="جست‌وجوی نام یا کلاس"};content.addView(search);val rows=LinearLayout(this).apply{orientation=1};content.addView(rows);val date=today();fun fill(q:String){rows.removeAllViews();db.pupils().filter{it.active&&(it.name.contains(q,true)||it.klass.contains(q,true))}.forEach{p->val cb=CheckBox(this).apply{text="${p.name} ـ ${p.grade} ـ ${p.klass}";isChecked=db.delays().any{it.pupilId==p.id&&it.date==date};isEnabled=!isChecked;setOnCheckedChangeListener{_,v->if(v){db.markLate(p.id,date);isEnabled=false;status.text="ثبت شد و روی گوشی ذخیره شد."}}};rows.addView(cb)}};search.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,a:Int,c:Int,d:Int){};override fun onTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){fill(s.toString())};override fun afterTextChanged(s:Editable?){}});fill("")}
 private fun studentScreen(){base("مدیریت دانش‌آموزان");content.addView(btn("ورود گروهی از فایل CSV اکسل"){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE),pickCsv)});content.addView(TextView(this).apply{text="ستون‌ها به ترتیب: نام و نام خانوادگی، پایه، کلاس. فایل را از Excel با UTF-8 CSV ذخیره کنید."});db.pupils().forEach{p->content.addView(TextView(this).apply{text="${p.name} | ${p.grade} | ${p.klass}"})}}
 private fun reportScreen(){
  base("گزارش ماهانه شمسی")
  val cal=PersianCalendar();val y=cal.get(Calendar.YEAR);val m=cal.get(Calendar.MONTH)+1
  val month=EditText(this).apply{setText("$y/${m.toString().padStart(2,'0')}");hint="سال/ماه شمسی مثل ۱۴۰۵/۰۸"};content.addView(month)
  val threshold=EditText(this).apply{inputType=2;setText(db.threshold().toString());hint="حد مجاز تأخیر"}
  content.addView(TextView(this).apply{text="حد مجاز تعداد تأخیر"});content.addView(threshold)
  val result=TextView(this).apply{textSize=15f};content.addView(result)
  content.addView(btn("نمایش گزارش"){
   val normalized=month.text.toString().map{ when(it){'۰'->'0';'۱'->'1';'۲'->'2';'۳'->'3';'۴'->'4';'۵'->'5';'۶'->'6';'۷'->'7';'۸'->'8';'۹'->'9';else->it } }
   val parts=normalized.split('/');if(parts.size!=2){result.text="ماه را مانند ۱۴۰۵/۰۸ وارد کنید.";return@btn}
   val yy=parts[0].toIntOrNull()?:0;val mm=parts[1].toIntOrNull()?:0;if(mm !in 1..12||yy<1300){result.text="سال یا ماه نامعتبر است.";return@btn}
   val lim=threshold.text.toString().toIntOrNull()?.coerceAtLeast(1)?:3;db.setThreshold(lim)
   val lines=mutableListOf<String>();val csv=StringBuilder().append("نام دانش‌آموز,پایه,کلاس,تعداد تأخیر,تاریخ‌های تأخیر,وضعیت\n")
   db.pupils().filter{it.active}.forEach{p->
    val dates=db.delays().filter{it.pupilId==p.id}.filter{r->val d=SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(r.date)?:return@filter false;val pc=PersianCalendar().apply{time=d};pc.get(Calendar.YEAR)==yy&&pc.get(Calendar.MONTH)+1==mm}.map{persianDate(it.date)}.sorted()
    if(dates.isNotEmpty()){val flag=if(dates.size>lim)"بالاتر از حد مجاز" else "در محدوده مجاز";val dateText=dates.joinToString("، ");lines.add("${p.name} | ${p.grade} | ${p.klass} | ${dates.size} مورد | $dateText | $flag");csv.append(listOf(p.name,p.grade,p.klass,dates.size.toString(),dateText,flag).joinToString(","){csvCell(it)}).append('\n')}
   }
   reportTitle="گزارش تأخیر ماه $yy/$mm";reportPdfLines=listOf(reportTitle,"حد هشدار: بیش از $lim مورد","")+if(lines.isEmpty())listOf("در این ماه تأخیری ثبت نشده است.") else lines
   reportCsvText=csv.toString();result.text=if(lines.isEmpty())"در این ماه تأخیری ثبت نشده است." else lines.joinToString("\n")
   content.addView(btn("ذخیره گزارش CSV (قابل بازشدن در Excel)"){startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).setType("text/csv").putExtra(Intent.EXTRA_TITLE,"lateness-$yy-${mm.toString().padStart(2,'0')}.csv"),saveReportCsv)})
   content.addView(btn("ذخیره گزارش PDF"){startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).setType("application/pdf").putExtra(Intent.EXTRA_TITLE,"lateness-$yy-${mm.toString().padStart(2,'0')}.pdf"),saveReportPdf)})
  })
 }
 private fun writeReportPdf(uri:Uri){
  val doc=PdfDocument();val pageWidth=595;val pageHeight=842;val margin=38f;val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{textSize=11f;typeface=Typeface.create("sans-serif",Typeface.NORMAL);textAlign=Paint.Align.RIGHT}
  var pageNum=1;var page=doc.startPage(PdfDocument.PageInfo.Builder(pageWidth,pageHeight,pageNum).create());var canvas=page.canvas;var y=48f
  fun newPage(){doc.finishPage(page);pageNum++;page=doc.startPage(PdfDocument.PageInfo.Builder(pageWidth,pageHeight,pageNum).create());canvas=page.canvas;y=48f}
  reportPdfLines.forEach{line->
   val words=line.split(Regex("\\s+"));var current=""
   words.forEach{w->val test=if(current.isEmpty())w else "$current $w";if(paint.measureText(test)>pageWidth-2*margin&&current.isNotEmpty()){if(y>pageHeight-45)newPage();canvas.drawText(current,pageWidth-margin,y,paint);y+=22;current=w}else current=test}
   if(y>pageHeight-45)newPage();canvas.drawText(current,pageWidth-margin,y,paint);y+=25
  }
  doc.finishPage(page);contentResolver.openOutputStream(uri)!!.use{doc.writeTo(it)};doc.close()
 }
 private fun syncDialog(){val input=EditText(this).apply{hint="http://192.168.1.10:8081/api/data";setText(getPreferences(0).getString("server",""))};AlertDialog.Builder(this).setTitle("آدرس سرور مدرسه").setMessage("گوشی و کامپیوتر باید موقتاً به یک وای‌فای وصل باشند. اطلاعات محلی حذف نمی‌شوند.").setView(input).setPositiveButton("همگام‌سازی"){_,_->val endpoint=input.text.toString().trim();getPreferences(0).edit().putString("server",endpoint).apply();Thread{try{val url=if(endpoint.endsWith("/api/data"))endpoint else endpoint.trimEnd('/')+"/api/data";val c=URL(url).openConnection() as HttpURLConnection;c.connectTimeout=7000;c.readTimeout=7000;c.requestMethod="GET";val remote=JSONObject(c.inputStream.bufferedReader(Charsets.UTF_8).use{it.readText()});c.disconnect();db.mergeJson(remote);val merged=db.exportJson();val post=URL(url).openConnection() as HttpURLConnection;post.connectTimeout=7000;post.readTimeout=7000;post.requestMethod="POST";post.doOutput=true;post.setRequestProperty("Content-Type","application/json; charset=utf-8");post.outputStream.use{it.write(merged.toString().toByteArray(Charsets.UTF_8))};val code=post.responseCode;post.disconnect();runOnUiThread{status.text=if(code in 200..299)"همگام‌سازی انجام شد؛ اطلاعات گوشی و سرور ادغام شدند." else "خطای سرور: $code"}}catch(e:Exception){runOnUiThread{status.text="اتصال برقرار نشد؛ اطلاعات روی گوشی محفوظ است. ${e.message}"}}}.start()}.setNegativeButton("لغو",null).show()}
 override fun onActivityResult(req:Int,res:Int,data:Intent?){super.onActivityResult(req,res,data);if(res!=RESULT_OK)return;val uri=data?.data?:return;try{when(req){pickCsv->{val txt=contentResolver.openInputStream(uri)!!.bufferedReader(Charsets.UTF_8).use{it.readText()};var n=0;txt.removePrefix("\uFEFF").lineSequence().forEach{line->val a=line.split(',', ';','\t').map{it.trim().trim('"')};if(a.size>=3&&a[0].isNotBlank()&&!a[0].contains("نام")){db.addPupil(a[0],a[1],a[2]);n++}};status.text="$n ردیف وارد شد."};saveJson->{contentResolver.openOutputStream(uri)!!.use{it.write(db.exportJson().toString(2).toByteArray(Charsets.UTF_8))};status.text="پشتیبان ذخیره شد."};pickJson->{val o=JSONObject(contentResolver.openInputStream(uri)!!.bufferedReader(Charsets.UTF_8).use{it.readText()});db.mergeJson(o);status.text="بازیابی پشتیبان انجام شد."};saveReportCsv->{contentResolver.openOutputStream(uri)!!.use{it.write(("\uFEFF"+reportCsvText).toByteArray(Charsets.UTF_8))};status.text="گزارش CSV ذخیره شد."};saveReportPdf->{writeReportPdf(uri);status.text="گزارش PDF ذخیره شد."}}}catch(e:Exception){status.text="خطا در پردازش فایل: ${e.message}"}}
}
